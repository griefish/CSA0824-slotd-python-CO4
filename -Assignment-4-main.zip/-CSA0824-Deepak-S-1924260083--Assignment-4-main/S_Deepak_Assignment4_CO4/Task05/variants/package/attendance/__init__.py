"""Attendance-processing package."""
